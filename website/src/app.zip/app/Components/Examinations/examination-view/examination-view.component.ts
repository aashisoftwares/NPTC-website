import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examination-view',
  templateUrl: './examination-view.component.html',
  styleUrls: ['./examination-view.component.css']
})
export class ExaminationViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
