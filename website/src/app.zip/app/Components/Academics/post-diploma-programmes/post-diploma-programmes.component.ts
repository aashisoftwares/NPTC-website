import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-diploma-programmes',
  templateUrl: './post-diploma-programmes.component.html',
  styleUrls: ['./post-diploma-programmes.component.css']
})
export class PostDiplomaProgrammesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
