import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aided-programmes',
  templateUrl: './aided-programmes.component.html',
  styleUrls: ['./aided-programmes.component.css']
})
export class AidedProgrammesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
