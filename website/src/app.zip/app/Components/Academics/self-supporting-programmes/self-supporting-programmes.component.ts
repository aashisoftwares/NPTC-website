import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-self-supporting-programmes',
  templateUrl: './self-supporting-programmes.component.html',
  styleUrls: ['./self-supporting-programmes.component.css']
})
export class SelfSupportingProgrammesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
