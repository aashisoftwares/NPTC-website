import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-offered',
  templateUrl: './courses-offered.component.html',
  styleUrls: ['./courses-offered.component.css']
})
export class CoursesOfferedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
