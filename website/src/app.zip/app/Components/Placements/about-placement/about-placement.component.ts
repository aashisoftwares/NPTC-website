import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-placement',
  templateUrl: './about-placement.component.html',
  styleUrls: ['./about-placement.component.css']
})
export class AboutPlacementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
