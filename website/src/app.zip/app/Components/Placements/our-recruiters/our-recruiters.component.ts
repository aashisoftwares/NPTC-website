import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-recruiters',
  templateUrl: './our-recruiters.component.html',
  styleUrls: ['./our-recruiters.component.css']
})
export class OurRecruitersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
