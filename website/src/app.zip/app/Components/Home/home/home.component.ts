import { Component, OnInit } from '@angular/core';
import { CarouselComponent, SlideComponent } from 'ngx-bootstrap/carousel/public_api';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor() { }

  ngOnInit() {

   }

}
