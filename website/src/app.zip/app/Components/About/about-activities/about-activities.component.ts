import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-activities',
  templateUrl: './about-activities.component.html',
  styleUrls: ['./about-activities.component.css']
})
export class AboutActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
