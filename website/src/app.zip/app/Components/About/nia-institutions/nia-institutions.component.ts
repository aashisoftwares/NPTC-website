import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nia-institutions',
  templateUrl: './nia-institutions.component.html',
  styleUrls: ['./nia-institutions.component.css']
})
export class NiaInstitutionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
