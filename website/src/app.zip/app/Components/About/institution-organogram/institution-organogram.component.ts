import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institution-organogram',
  templateUrl: './institution-organogram.component.html',
  styleUrls: ['./institution-organogram.component.css']
})
export class InstitutionOrganogramComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
