import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-anti-ragging-committee',
  templateUrl: './about-anti-ragging-committee.component.html',
  styleUrls: ['./about-anti-ragging-committee.component.css']
})
export class AboutAntiRaggingCommitteeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
