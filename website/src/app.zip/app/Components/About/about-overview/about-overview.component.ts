import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-overview',
  templateUrl: './about-overview.component.html',
  styleUrls: ['./about-overview.component.css']
})
export class AboutOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
