import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-view',
  templateUrl: './staff-view.component.html',
  styleUrls: ['./staff-view.component.css']
})
export class StaffViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
