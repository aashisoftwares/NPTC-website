import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salient-features',
  templateUrl: './salient-features.component.html',
  styleUrls: ['./salient-features.component.css']
})
export class SalientFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
