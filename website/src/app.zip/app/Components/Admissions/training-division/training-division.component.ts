import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-division',
  templateUrl: './training-division.component.html',
  styleUrls: ['./training-division.component.css']
})
export class TrainingDivisionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
