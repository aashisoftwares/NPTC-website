import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placement-record',
  templateUrl: './placement-record.component.html',
  styleUrls: ['./placement-record.component.css']
})
export class PlacementRecordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
