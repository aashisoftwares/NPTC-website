import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-admission',
  templateUrl: './student-admission.component.html',
  styleUrls: ['./student-admission.component.css']
})
export class StudentAdmissionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
