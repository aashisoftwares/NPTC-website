import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-criteria',
  templateUrl: './eligibility-criteria.component.html',
  styleUrls: ['./eligibility-criteria.component.css']
})
export class EligibilityCriteriaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
