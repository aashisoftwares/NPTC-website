import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-at-nptc',
  templateUrl: './life-at-nptc.component.html',
  styleUrls: ['./life-at-nptc.component.css']
})
export class LifeAtNPTCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
